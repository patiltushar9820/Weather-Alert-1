export class AlertType {
    name: string;

    constructor(item: AlertType) {
        Object.assign(this, item);
    }
}

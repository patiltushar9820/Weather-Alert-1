export class Areas {
    area_name: Array<string>;
    constructor(item:Areas) {
        Object.assign(this, item);
    }
}
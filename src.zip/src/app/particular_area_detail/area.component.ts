import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { ParticularAreaServiceService } from '../core/services/particular-area-service.service';
import { particularAreaDetail } from '../core/models/particularArea.model';

@Component({
  selector: 'app-area',
  templateUrl: './area.component.html',
  styleUrls: ['./area.component.scss']
})
export class AreaComponent implements OnInit {

  particularareaDetail:particularAreaDetail[];

  particular_area_areadescr:particularAreaDetail[];

  areadetail:Array<string>;

  event_count:number;
  

  constructor(private particularAreaServices: ParticularAreaServiceService , 
    private route: ActivatedRoute) { }

  ngOnInit() {

    /* this.route.paramMap.subscribe(param => {
      this.area = param.get('data')
      console.log(this.area)
    })
    */

    let particulararea =this.route.snapshot.params['data'];
    //this.particularAreaServices.getUser(username).then(user => this.user = user);
    console.log("particular ",particulararea);

    
    this.particularAreaServices.getAreaDetail(particulararea).subscribe(res => {
      this.particularareaDetail = res;
     console.log("All Data: ",this.particularareaDetail)
     //length of the particularareaDetail length
    //  console.log(this.particularareaDetail)

    /*  //for loop
      for (let i=0; i<this.particularareaDetail.length;i++ )
      {
        console.log("For loop data:",this.particularareaDetail[i])
      }

      */
      this.areadetail=this.particularareaDetail["features"];
      
     for(let i of this.areadetail){
       console.log(" Areas Affected Zone :",i["properties"].affectedZones,"\n")
       console.log(" Areas Description :",i["properties"].areaDesc,"\n")
       
       console.log(" Areas Event  :",i["properties"].event,"\n")
      }
     
      this.event_count=this.areadetail.length;

      //for each loop
      
     
      
    })
    
  
  }

}

export class Areas {
    area_name: string;

    constructor(item:Areas) {
        Object.assign(this, item);
    }
}
export class particularAreaDetail {
    particular_area_detail: Array<Object>;
    

    constructor(item:particularAreaDetail) {
        Object.assign(this, item);
    }
}